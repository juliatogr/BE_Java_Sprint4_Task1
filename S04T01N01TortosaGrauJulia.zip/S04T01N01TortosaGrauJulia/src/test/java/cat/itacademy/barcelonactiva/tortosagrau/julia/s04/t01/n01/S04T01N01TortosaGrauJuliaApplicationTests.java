package cat.itacademy.barcelonactiva.tortosagrau.julia.s04.t01.n01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S04T01N01TortosaGrauJuliaApplicationTests {

	@Test
	void contextLoads() {
	}

}
